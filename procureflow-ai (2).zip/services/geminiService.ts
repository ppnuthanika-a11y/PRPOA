import { GoogleGenAI } from "@google/genai";
import { PurchaseRequest } from "../types";

const getClient = () => {
    const apiKey = process.env.API_KEY;
    if (!apiKey) return null;
    return new GoogleGenAI({ apiKey });
};

export const analyzePRJustification = async (pr: PurchaseRequest): Promise<string> => {
    const ai = getClient();
    if (!ai) return "API Key not configured.";

    const prompt = `
    You are a procurement audit AI. Analyze the following Purchase Request.
    
    Department: ${pr.department}
    Justification: ${pr.justification}
    Total Amount: ${pr.totalAmount} THB
    Items:
    ${pr.items.map(i => `- ${i.description} (Qty: ${i.quantity}, Price: ${i.unitPrice})`).join('\n')}

    Please provide a brief, professional assessment (max 50 words) focusing on:
    1. Does the justification seem valid for the items requested?
    2. Is the pricing reasonable (general estimation)?
    3. Any potential policy flags?
    `;

    try {
        const response = await ai.models.generateContent({
            model: 'gemini-2.5-flash',
            contents: prompt,
        });
        return response.text || "Analysis failed.";
    } catch (error) {
        console.error("Gemini Error:", error);
        return "Unable to perform AI analysis at this time.";
    }
};
