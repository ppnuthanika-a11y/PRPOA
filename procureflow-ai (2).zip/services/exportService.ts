import jsPDF from 'jspdf';
import autoTable from 'jspdf-autotable';
import * as XLSX from 'xlsx';
import { PurchaseOrder, PurchaseRequest, UserRole } from '../types';

// Helper to format currency
const formatCurrency = (amount: number) => {
    // Changed to en-US to avoid non-ASCII currency symbols (like ฿) which render as ? in standard jsPDF fonts
    // Formats as "1,234.56"
    return new Intl.NumberFormat('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(amount);
};

// Helper to format date time
const formatDateTime = (isoString: string) => {
    return new Date(isoString).toLocaleString('en-GB', {
        year: 'numeric', month: '2-digit', day: '2-digit',
        hour: '2-digit', minute: '2-digit',
        hour12: false
    });
};

// Mock function to get Approver Name based on Role (In a real app, this would come from user data)
const getApproverName = (role: UserRole): string => {
    switch (role) {
        case 'APPROVER_1': return "Piyachart (IT Manager)";
        case 'APPROVER_2': return "Sureeporn (Director)";
        default: return "Authorized Person";
    }
};

// Shared PDF generation logic
const generatePDFDoc = (title: string, refNumber: string, dateStr: string, vendorName: string | null, pr: PurchaseRequest) => {
    const doc = new jsPDF();

    // --- Header ---
    doc.setFillColor(30, 41, 59); // Slate 800
    doc.rect(0, 0, 210, 40, 'F'); // Dark header background

    doc.setFontSize(20);
    doc.setTextColor(255, 255, 255);
    doc.setFont("helvetica", "bold");
    doc.text(title, 14, 26);

    doc.setFontSize(10);
    doc.setTextColor(200, 200, 200);
    doc.setFont("helvetica", "normal");
    doc.text("ProcureFlow Co., Ltd.", 150, 18);
    doc.text("123 Business Park, Bangkok", 150, 23);
    doc.text("Tax ID: 0105551234567", 150, 28);

    // --- Info Section ---
    let yPos = 55;
    
    // Left Column: Document Details
    doc.setTextColor(40);
    doc.setFontSize(10);
    doc.setFont("helvetica", "bold");
    doc.text("DOCUMENT INFO", 14, yPos);
    
    doc.setFont("helvetica", "normal");
    doc.setFontSize(10);
    doc.text(`Ref Number:`, 14, yPos + 7);
    doc.text(`Date:`, 14, yPos + 13);
    if (vendorName) {
        doc.text(`Vendor:`, 14, yPos + 19);
    }

    doc.text(refNumber, 45, yPos + 7);
    doc.text(dateStr, 45, yPos + 13);
    if (vendorName) {
        doc.text(vendorName, 45, yPos + 19);
    }

    // Right Column: Request Details
    doc.setFont("helvetica", "bold");
    doc.text("REQUESTER DETAILS", 120, yPos);

    doc.setFont("helvetica", "normal");
    doc.text(`Requester:`, 120, yPos + 7);
    doc.text(`Department:`, 120, yPos + 13);
    doc.text(`PR ID:`, 120, yPos + 19);

    doc.text(pr.requesterName, 150, yPos + 7);
    doc.text(pr.department, 150, yPos + 13);
    doc.text(pr.id, 150, yPos + 19);

    // --- Items Table ---
    const tableBody = pr.items.map(item => [
        item.description,
        item.quantity,
        formatCurrency(item.unitPrice),
        formatCurrency(item.total)
    ]);

    autoTable(doc, {
        startY: yPos + 30,
        head: [['Description', 'Qty', 'Unit Price (THB)', 'Total (THB)']],
        body: tableBody,
        foot: [['', '', 'Grand Total', formatCurrency(pr.totalAmount)]],
        theme: 'striped',
        headStyles: { fillColor: [79, 70, 229], textColor: 255, fontStyle: 'bold' },
        footStyles: { fillColor: [241, 245, 249], textColor: 0, fontStyle: 'bold' },
        styles: { fontSize: 9, cellPadding: 3 },
        columnStyles: {
            0: { cellWidth: 'auto' },
            1: { halign: 'center' },
            2: { halign: 'right' }, // Right align Unit Price
            3: { halign: 'right' }  // Right align Total
        }
    });

    // --- Approval Section ---
    let finalY = (doc as any).lastAutoTable.finalY + 20;

    // Ensure we don't run off the page
    if (finalY > 230) {
        doc.addPage();
        finalY = 20;
    }

    doc.setFontSize(11);
    doc.setTextColor(30);
    doc.setFont("helvetica", "bold");
    doc.text("APPROVAL AUTHORIZATION", 14, finalY);
    
    doc.setDrawColor(200);
    doc.line(14, finalY + 2, 196, finalY + 2);
    
    finalY += 10;
    
    const l1Approval = pr.approvalHistory.find(h => h.role === 'APPROVER_1' && h.action === 'APPROVE');
    const l2Approval = pr.approvalHistory.find(h => h.role === 'APPROVER_2' && h.action === 'APPROVE');

    // Draw Approver Boxes
    const drawApproverBox = (x: number, roleLabel: string, name: string, date: string, isApproved: boolean) => {
        doc.setDrawColor(220);
        doc.setFillColor(isApproved ? 250 : 255, isApproved ? 255 : 255, isApproved ? 250 : 255);
        doc.roundedRect(x, finalY, 85, 35, 2, 2, 'FD');

        doc.setFontSize(8);
        doc.setTextColor(100);
        doc.text(roleLabel, x + 5, finalY + 6);

        if (isApproved) {
            doc.setFontSize(10);
            doc.setTextColor(0);
            doc.setFont("helvetica", "bold");
            doc.text(name, x + 5, finalY + 14); // Approver Name

            doc.setFontSize(9);
            doc.setTextColor(0, 100, 0); // Dark Green
            doc.setFont("helvetica", "italic");
            doc.text("Digitally Approved", x + 5, finalY + 22);
            
            doc.setFontSize(8);
            doc.setTextColor(80);
            doc.setFont("helvetica", "normal");
            doc.text(`Date: ${date}`, x + 5, finalY + 30);
        } else {
            doc.text("Pending / Not Required", x + 5, finalY + 15);
        }
    };

    // Level 1 Box
    if (l1Approval) {
        drawApproverBox(14, "Level 1 Authorization (Manager)", getApproverName('APPROVER_1'), formatDateTime(l1Approval.date), true);
    } else {
        drawApproverBox(14, "Level 1 Authorization (Manager)", "-", "-", false);
    }

    // Level 2 Box
    if (l2Approval) {
        drawApproverBox(110, "Level 2 Authorization (Director)", getApproverName('APPROVER_2'), formatDateTime(l2Approval.date), true);
    } else if (pr.totalAmount <= 50000 && l1Approval) {
         // Mark as not required if L1 done and amount low
         doc.setDrawColor(220);
         doc.setFillColor(245, 245, 245);
         doc.roundedRect(110, finalY, 85, 35, 2, 2, 'FD');
         doc.setFontSize(8); doc.setTextColor(150);
         doc.text("Level 2 Authorization", 115, finalY + 6);
         doc.text("Not Required (< 50k)", 115, finalY + 18);
    } else {
         drawApproverBox(110, "Level 2 Authorization (Director)", "-", "-", false);
    }

    // --- Footer & Disclaimer ---
    finalY += 45;

    doc.setFont("helvetica", "normal");
    doc.setFontSize(9);
    doc.setTextColor(100);
    
    // Disclaimer Box
    doc.setDrawColor(230);
    doc.setFillColor(248, 250, 252); // Very light slate
    doc.rect(14, finalY, 182, 28, 'F');

    doc.setTextColor(70);
    doc.setFont("helvetica", "bold");
    doc.text("SYSTEM GENERATED DOCUMENT", 18, finalY + 6);
    
    doc.setFont("helvetica", "normal");
    doc.setFontSize(8);
    doc.setTextColor(100);
    doc.text("This document has been electronically generated and approved via the ProcureFlow System.", 18, finalY + 12);
    doc.text("The approvals listed above are recorded in the system database with valid timestamps.", 18, finalY + 16);
    
    doc.setFont("helvetica", "bolditalic");
    doc.setTextColor(220, 38, 38); // Red-ish for emphasis
    doc.text("*** NO MANUAL SIGNATURE REQUIRED / ELECTRONIC APPROVAL ***", 18, finalY + 23);

    // Bottom Timestamp
    const printTime = new Date().toLocaleString('en-GB');
    doc.setFont("helvetica", "normal");
    doc.setFontSize(7);
    doc.setTextColor(180);
    doc.text(`Generated on: ${printTime} | Ref: ${refNumber}`, 196, 290, { align: 'right' });

    return doc;
};

export const generatePO_PDF = (po: PurchaseOrder) => {
    const doc = generatePDFDoc(
        "PURCHASE ORDER", 
        po.poNumber, 
        new Date(po.generatedDate).toLocaleDateString('th-TH'), 
        po.vendorName, 
        po.prSnapshot
    );
    doc.save(`${po.poNumber}.pdf`);
};

export const previewPR_PDF = (pr: PurchaseRequest) => {
    // Use PR ID as Ref Number, Date from PR, No vendor yet
    const doc = generatePDFDoc(
        "PURCHASE REQUEST (APPROVED)", 
        pr.id, 
        pr.date, 
        null, 
        pr
    );
    
    // Open in new tab instead of saving
    const blob = doc.output('bloburl');
    window.open(blob, '_blank');
};

export const exportToExcel = (prs: PurchaseRequest[], pos: PurchaseOrder[]) => {
    const prData = prs.map(pr => ({
        ID: pr.id,
        Date: pr.date,
        Requester: pr.requesterName,
        Department: pr.department,
        Total: pr.totalAmount,
        Status: pr.status,
        ItemsCount: pr.items.length
    }));

    const poData = pos.map(po => ({
        PONumber: po.poNumber,
        Date: po.generatedDate,
        Vendor: po.vendorName,
        PR_Ref: po.prId,
        Amount: po.prSnapshot.totalAmount
    }));

    const wb = XLSX.utils.book_new();
    const wsPR = XLSX.utils.json_to_sheet(prData);
    const wsPO = XLSX.utils.json_to_sheet(poData);

    XLSX.utils.book_append_sheet(wb, wsPR, "Purchase Requests");
    XLSX.utils.book_append_sheet(wb, wsPO, "Purchase Orders");

    XLSX.writeFile(wb, "Procurement_Report.xlsx");
};