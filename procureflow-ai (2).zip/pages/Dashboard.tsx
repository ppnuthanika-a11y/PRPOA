import React from 'react';
import { useApp } from '../context/AppContext';
import { PRStatus } from '../types';

export const Dashboard: React.FC = () => {
    const { requests, orders } = useApp();

    const pendingCount = requests.filter(r => r.status === PRStatus.PENDING_L1 || r.status === PRStatus.PENDING_L2).length;
    const approvedCount = requests.filter(r => r.status === PRStatus.APPROVED).length;
    const totalVolume = orders.reduce((acc, curr) => acc + curr.prSnapshot.totalAmount, 0);

    const StatCard = ({ label, value, icon, color, sub }: any) => (
        <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-sm flex items-start justify-between transition hover:shadow-md h-full">
            <div>
                <p className="text-sm font-medium text-slate-500 mb-1">{label}</p>
                <h3 className="text-3xl font-bold text-slate-900">{value}</h3>
                {sub && <p className="text-xs text-slate-400 mt-2 flex items-center gap-1"><i className="bi bi-arrow-up-right"></i> {sub}</p>}
            </div>
            <div className={`w-12 h-12 rounded-xl ${color} flex items-center justify-center shadow-sm`}>
                <i className={`bi ${icon} text-xl text-white`}></i>
            </div>
        </div>
    );

    return (
        <div className="space-y-6 md:space-y-8">
            <div>
                <h2 className="text-2xl md:text-3xl font-bold text-slate-800">Dashboard Overview</h2>
                <p className="text-slate-500 mt-1">Welcome back, here is what's happening with your procurement today.</p>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <StatCard 
                    label="Pending Approvals" 
                    value={pendingCount} 
                    icon="bi-clock-history" 
                    color="bg-gradient-to-br from-amber-400 to-orange-500"
                    sub="Requests awaiting action"
                />
                <StatCard 
                    label="Active Orders" 
                    value={orders.length} 
                    icon="bi-receipt" 
                    color="bg-gradient-to-br from-blue-400 to-indigo-500"
                    sub="Purchase orders generated"
                />
                <StatCard 
                    label="Total Volume (YTD)" 
                    value={new Intl.NumberFormat('th-TH', { style: 'currency', currency: 'THB', maximumFractionDigits: 0 }).format(totalVolume)} 
                    icon="bi-cash-stack" 
                    color="bg-gradient-to-br from-emerald-400 to-teal-500"
                    sub="Total value converted"
                />
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 md:gap-8">
                 <div className="lg:col-span-2 bg-white p-6 md:p-8 rounded-xl border border-slate-200 shadow-sm flex flex-col">
                     <div className="flex justify-between items-center mb-6">
                        <h3 className="font-bold text-lg text-slate-800">Recent Activity</h3>
                        <button className="text-sm text-indigo-600 hover:text-indigo-800 font-medium">View All</button>
                     </div>
                     <div className="space-y-0 divide-y divide-slate-100 flex-1">
                        {requests.slice(0, 5).map((req) => (
                            <div key={req.id} className="flex items-center justify-between py-4 hover:bg-slate-50 px-2 rounded transition -mx-2">
                                <div className="flex items-center gap-4">
                                    <div className={`w-10 h-10 rounded-full flex items-center justify-center text-lg flex-shrink-0
                                        ${req.status.includes('APPROVED') ? 'bg-green-100 text-green-600' : 
                                          req.status.includes('REJECTED') ? 'bg-red-100 text-red-600' : 
                                          'bg-blue-100 text-blue-600'}
                                    `}>
                                        <i className={`bi ${req.status.includes('APPROVED') ? 'bi-check-lg' : req.status.includes('REJECTED') ? 'bi-x-lg' : 'bi-hourglass-split'}`}></i>
                                    </div>
                                    <div className="min-w-0">
                                        <p className="text-sm font-bold text-slate-900 truncate">{req.id}</p>
                                        <p className="text-xs text-slate-500 truncate">{req.requesterName} • {req.department}</p>
                                    </div>
                                </div>
                                <div className="text-right flex-shrink-0 pl-2">
                                    <span className={`text-xs px-2.5 py-1 rounded-full font-medium border ${
                                        req.status.includes('APPROVED') ? 'bg-green-50 text-green-700 border-green-200' :
                                        req.status.includes('PENDING') ? 'bg-yellow-50 text-yellow-700 border-yellow-200' : 
                                        req.status.includes('REJECTED') ? 'bg-red-50 text-red-700 border-red-200' :
                                        'bg-slate-50 text-slate-600 border-slate-200'
                                    }`}>
                                        {req.status.replace(/_/g, ' ')}
                                    </span>
                                    <p className="text-xs text-slate-400 mt-1">{req.date}</p>
                                </div>
                            </div>
                        ))}
                        {requests.length === 0 && (
                            <div className="py-12 text-center text-slate-400">No activity recorded yet.</div>
                        )}
                     </div>
                 </div>
                 
                 <div className="lg:col-span-1 flex flex-col gap-6">
                    <div className="bg-gradient-to-br from-slate-800 to-slate-900 p-8 rounded-xl text-white flex flex-col justify-center items-start relative overflow-hidden shadow-lg min-h-[250px]">
                        <div className="absolute top-0 right-0 -mt-4 -mr-4 w-32 h-32 bg-white opacity-5 rounded-full blur-2xl"></div>
                        <div className="relative z-10">
                            <div className="w-12 h-12 bg-white/10 rounded-lg flex items-center justify-center mb-4 backdrop-blur-sm border border-white/10">
                                <i className="bi bi-robot text-2xl text-emerald-400"></i>
                            </div>
                            <h3 className="font-bold text-xl mb-2">AI Insights Enabled</h3>
                            <p className="text-slate-300 mb-6 text-sm leading-relaxed">
                                Your PRs are being automatically analyzed for policy compliance and pricing anomalies using Gemini 2.0 Flash.
                            </p>
                            <div className="flex gap-3 w-full items-center">
                                <div className="h-1.5 flex-1 bg-slate-700 rounded-full overflow-hidden">
                                    <div className="h-full bg-emerald-500 w-3/4 animate-pulse"></div>
                                </div>
                                <span className="text-xs text-emerald-400 font-mono">Active</span>
                            </div>
                        </div>
                    </div>
                    
                    <div className="bg-indigo-50 p-6 rounded-xl border border-indigo-100 flex-1">
                         <h4 className="font-bold text-indigo-900 mb-4">Quick Actions</h4>
                         <div className="space-y-3">
                            <button className="w-full text-left px-4 py-4 bg-white rounded-lg border border-indigo-100 text-sm text-indigo-700 font-medium hover:shadow-md transition flex justify-between items-center group">
                                <span><i className="bi bi-file-earmark-plus mr-2"></i> Create New Report</span>
                                <i className="bi bi-arrow-right text-indigo-400 group-hover:text-indigo-600 transition"></i>
                            </button>
                            <button className="w-full text-left px-4 py-4 bg-white rounded-lg border border-indigo-100 text-sm text-indigo-700 font-medium hover:shadow-md transition flex justify-between items-center group">
                                <span><i className="bi bi-people mr-2"></i> Manage Vendor List</span>
                                <i className="bi bi-arrow-right text-indigo-400 group-hover:text-indigo-600 transition"></i>
                            </button>
                         </div>
                    </div>
                 </div>
            </div>
        </div>
    );
};