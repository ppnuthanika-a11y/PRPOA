
import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { ApprovalLimit } from '../types';

export const LimitManagement: React.FC = () => {
    const { approvalLimits, addLimit, updateLimit, deleteLimit } = useApp();
    const [isModalOpen, setIsModalOpen] = useState(false);
    const [currentLimit, setCurrentLimit] = useState<Partial<ApprovalLimit>>({});

    const handleEdit = (limit: ApprovalLimit) => {
        setCurrentLimit({ ...limit });
        setIsModalOpen(true);
    };

    const handleAdd = () => {
        setCurrentLimit({}); 
        setIsModalOpen(true);
    };

    const handleDelete = (id: string) => {
        if (approvalLimits.length <= 1) {
            alert("You must have at least one approval limit configured.");
            return;
        }
        if (window.confirm("Are you sure?")) {
            deleteLimit(id);
        }
    };

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        if (currentLimit.id) {
            updateLimit(currentLimit as ApprovalLimit);
        } else {
            addLimit({ 
                ...currentLimit, 
                id: Math.random().toString(36).substr(2, 9) 
            } as ApprovalLimit);
        }
        setIsModalOpen(false);
    };

    return (
        <div className="space-y-6">
            <div className="flex justify-between items-center">
                <div>
                    <h2 className="text-2xl font-bold text-slate-800">Limit Management</h2>
                    <p className="text-slate-500">Configure approval thresholds and monetary limits.</p>
                </div>
                <button onClick={handleAdd} className="bg-emerald-600 text-white px-4 py-2 rounded-lg flex items-center gap-2 hover:bg-emerald-700 transition shadow-sm">
                    <i className="bi bi-sliders"></i> Add Limit Rule
                </button>
            </div>

            <div className="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden">
                <table className="w-full text-sm text-left">
                    <thead className="bg-slate-50 text-slate-500 font-semibold border-b border-slate-200">
                        <tr>
                            <th className="px-6 py-4">Rule Name</th>
                            <th className="px-6 py-4 text-right">Amount Limit (THB)</th>
                            <th className="px-6 py-4">Description</th>
                            <th className="px-6 py-4 text-center">Action</th>
                        </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                        {approvalLimits.map(limit => (
                            <tr key={limit.id} className="hover:bg-slate-50">
                                <td className="px-6 py-4 font-medium text-slate-800">{limit.name}</td>
                                <td className="px-6 py-4 text-right font-bold text-emerald-600">
                                    {new Intl.NumberFormat('th-TH', { style: 'currency', currency: 'THB' }).format(limit.amount)}
                                </td>
                                <td className="px-6 py-4 text-slate-500">{limit.description || '-'}</td>
                                <td className="px-6 py-4 text-center flex justify-center gap-2">
                                    <button onClick={() => handleEdit(limit)} className="text-indigo-600 hover:bg-indigo-50 p-2 rounded"><i className="bi bi-pencil-square"></i></button>
                                    <button onClick={() => handleDelete(limit.id)} className="text-red-600 hover:bg-red-50 p-2 rounded"><i className="bi bi-trash"></i></button>
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            </div>

            {/* Modal */}
            {isModalOpen && (
                <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 backdrop-blur-sm">
                    <div className="bg-white rounded-xl shadow-xl w-full max-w-md p-6">
                        <h3 className="text-lg font-bold mb-4">{currentLimit.id ? 'Edit Limit' : 'Add New Limit'}</h3>
                        <form onSubmit={handleSubmit} className="space-y-4">
                            <div>
                                <label className="block text-sm font-medium text-slate-700 mb-1">Rule Name</label>
                                <input required type="text" placeholder="e.g. Level 1 Threshold" className="w-full p-2 border rounded-lg" value={currentLimit.name || ''} onChange={e => setCurrentLimit({...currentLimit, name: e.target.value})} />
                            </div>
                            <div>
                                <label className="block text-sm font-medium text-slate-700 mb-1">Max Amount (THB)</label>
                                <input required type="number" className="w-full p-2 border rounded-lg" value={currentLimit.amount || ''} onChange={e => setCurrentLimit({...currentLimit, amount: Number(e.target.value)})} />
                                <p className="text-xs text-slate-400 mt-1">Amounts above this will require Level 2 Approval.</p>
                            </div>
                            <div>
                                <label className="block text-sm font-medium text-slate-700 mb-1">Description</label>
                                <textarea className="w-full p-2 border rounded-lg" rows={3} value={currentLimit.description || ''} onChange={e => setCurrentLimit({...currentLimit, description: e.target.value})} />
                            </div>
                            
                            <div className="flex justify-end gap-3 pt-4">
                                <button type="button" onClick={() => setIsModalOpen(false)} className="px-4 py-2 text-slate-600 hover:bg-slate-100 rounded-lg">Cancel</button>
                                <button type="submit" className="px-4 py-2 bg-emerald-600 text-white rounded-lg hover:bg-emerald-700">Save Limit</button>
                            </div>
                        </form>
                    </div>
                </div>
            )}
        </div>
    );
};
