
import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { User } from '../types';

export const UserManagement: React.FC = () => {
    const { users, addUser, updateUser, deleteUser } = useApp();
    const [isModalOpen, setIsModalOpen] = useState(false);
    const [currentUser, setCurrentUser] = useState<Partial<User>>({});
    
    // Filter only REQUESTER for this view (as requested, separate pages for Approvers)
    const requesterUsers = users.filter(u => u.role === 'REQUESTER');
    
    const approver1s = users.filter(u => u.role === 'APPROVER_1');
    const approver2s = users.filter(u => u.role === 'APPROVER_2');

    const handleEdit = (user: User) => {
        setCurrentUser({ ...user });
        setIsModalOpen(true);
    };

    const handleAdd = () => {
        setCurrentUser({ role: 'REQUESTER' }); // Default role for this page
        setIsModalOpen(true);
    };

    const handleDelete = (id: string) => {
        if (window.confirm("Are you sure you want to delete this user?")) {
            deleteUser(id);
        }
    };

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        if (currentUser.id) {
            updateUser(currentUser as User);
        } else {
            addUser({ 
                ...currentUser, 
                id: Math.random().toString(36).substr(2, 9),
                role: 'REQUESTER' 
            } as User);
        }
        setIsModalOpen(false);
    };

    return (
        <div className="space-y-6">
            <div className="flex justify-between items-center">
                <div>
                    <h2 className="text-2xl font-bold text-slate-800">User Management</h2>
                    <p className="text-slate-500">Manage general users (Requesters) and assign their approvers.</p>
                </div>
                <button onClick={handleAdd} className="bg-blue-600 text-white px-4 py-2 rounded-lg flex items-center gap-2 hover:bg-blue-700 transition shadow-sm">
                    <i className="bi bi-person-plus-fill"></i> Add User
                </button>
            </div>

            <div className="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden">
                <table className="w-full text-sm text-left">
                    <thead className="bg-slate-50 text-slate-500 font-semibold border-b border-slate-200">
                        <tr>
                            <th className="px-6 py-4">Name</th>
                            <th className="px-6 py-4">Email</th>
                            <th className="px-6 py-4">Department</th>
                            <th className="px-6 py-4">Approver 1</th>
                            <th className="px-6 py-4">Approver 2</th>
                            <th className="px-6 py-4 text-center">Action</th>
                        </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                        {requesterUsers.map(user => (
                            <tr key={user.id} className="hover:bg-slate-50">
                                <td className="px-6 py-4 font-medium text-slate-800">{user.name}</td>
                                <td className="px-6 py-4 text-slate-500">{user.email}</td>
                                <td className="px-6 py-4">
                                    <span className="px-2 py-1 bg-slate-100 rounded text-xs font-medium">{user.department}</span>
                                </td>
                                <td className="px-6 py-4 text-slate-600 text-xs">
                                    {approver1s.find(a => a.id === user.approver1Id)?.name || <span className="text-red-400 italic">Not Assigned</span>}
                                </td>
                                <td className="px-6 py-4 text-slate-600 text-xs">
                                    {approver2s.find(a => a.id === user.approver2Id)?.name || <span className="text-red-400 italic">Not Assigned</span>}
                                </td>
                                <td className="px-6 py-4 text-center flex justify-center gap-2">
                                    <button onClick={() => handleEdit(user)} className="text-indigo-600 hover:bg-indigo-50 p-2 rounded"><i className="bi bi-pencil-square"></i></button>
                                    <button onClick={() => handleDelete(user.id)} className="text-red-600 hover:bg-red-50 p-2 rounded"><i className="bi bi-trash"></i></button>
                                </td>
                            </tr>
                        ))}
                        {requesterUsers.length === 0 && <tr><td colSpan={6} className="text-center py-8 text-slate-400">No users found.</td></tr>}
                    </tbody>
                </table>
            </div>

            {/* User Modal */}
            {isModalOpen && (
                <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 backdrop-blur-sm">
                    <div className="bg-white rounded-xl shadow-xl w-full max-w-md p-6">
                        <h3 className="text-lg font-bold mb-4">{currentUser.id ? 'Edit User' : 'Add New User'}</h3>
                        <form onSubmit={handleSubmit} className="space-y-4">
                            <div>
                                <label className="block text-sm font-medium text-slate-700 mb-1">Name</label>
                                <input required type="text" className="w-full p-2 border rounded-lg" value={currentUser.name || ''} onChange={e => setCurrentUser({...currentUser, name: e.target.value})} />
                            </div>
                            <div>
                                <label className="block text-sm font-medium text-slate-700 mb-1">Email</label>
                                <input required type="email" className="w-full p-2 border rounded-lg" value={currentUser.email || ''} onChange={e => setCurrentUser({...currentUser, email: e.target.value})} />
                            </div>
                            <div>
                                <label className="block text-sm font-medium text-slate-700 mb-1">Department</label>
                                <select required className="w-full p-2 border rounded-lg" value={currentUser.department || ''} onChange={e => setCurrentUser({...currentUser, department: e.target.value})}>
                                    <option value="">Select Department</option>
                                    <option value="IT">IT</option>
                                    <option value="HR">HR</option>
                                    <option value="Marketing">Marketing</option>
                                    <option value="Operations">Operations</option>
                                    <option value="Finance">Finance</option>
                                </select>
                            </div>
                            
                            <div className="pt-2 border-t border-slate-100 mt-2">
                                <p className="text-xs font-bold text-slate-500 uppercase mb-2">Approver Assignment</p>
                                <div className="space-y-3">
                                    <div>
                                        <label className="block text-sm font-medium text-slate-700 mb-1">Approver Level 1</label>
                                        <select className="w-full p-2 border rounded-lg text-sm" value={currentUser.approver1Id || ''} onChange={e => setCurrentUser({...currentUser, approver1Id: e.target.value})}>
                                            <option value="">Select Level 1 Approver</option>
                                            {approver1s.map(a => <option key={a.id} value={a.id}>{a.name} ({a.department})</option>)}
                                        </select>
                                    </div>
                                    <div>
                                        <label className="block text-sm font-medium text-slate-700 mb-1">Approver Level 2</label>
                                        <select className="w-full p-2 border rounded-lg text-sm" value={currentUser.approver2Id || ''} onChange={e => setCurrentUser({...currentUser, approver2Id: e.target.value})}>
                                            <option value="">Select Level 2 Approver</option>
                                            {approver2s.map(a => <option key={a.id} value={a.id}>{a.name} ({a.department})</option>)}
                                        </select>
                                    </div>
                                </div>
                            </div>

                            <div className="flex justify-end gap-3 pt-4">
                                <button type="button" onClick={() => setIsModalOpen(false)} className="px-4 py-2 text-slate-600 hover:bg-slate-100 rounded-lg">Cancel</button>
                                <button type="submit" className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700">Save User</button>
                            </div>
                        </form>
                    </div>
                </div>
            )}
        </div>
    );
};
