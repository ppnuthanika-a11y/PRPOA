
import React from 'react';
import { useApp } from '../context/AppContext';
import { UserRole } from '../types';

interface SidebarProps {
    activePage: string;
    setActivePage: (page: string) => void;
    isOpen: boolean;
    setIsOpen: (isOpen: boolean) => void;
}

export const Sidebar: React.FC<SidebarProps> = ({ activePage, setActivePage, isOpen, setIsOpen }) => {
    const { role, setRole } = useApp();

    const menuItems = [
        { id: 'dashboard', label: 'Dashboard', icon: 'bi-speedometer2' },
        { id: 'create-pr', label: 'Create Request', icon: 'bi-plus-circle-dotted', show: role === 'REQUESTER' },
        { id: 'requests', label: 'My Requests', icon: 'bi-list-ul', show: role === 'REQUESTER' },
        { id: 'approvals', label: 'Pending Approvals', icon: 'bi-check2-square', show: role !== 'REQUESTER' },
        { id: 'orders', label: 'Purchase Orders', icon: 'bi-file-earmark-text' },
        { id: 'reports', label: 'Reports', icon: 'bi-graph-up' },
    ];

    const adminItems = [
        { id: 'manage-users', label: 'User Management', icon: 'bi-people-fill' },
        { id: 'manage-approvers', label: 'Approver Mgmt', icon: 'bi-person-badge' },
        { id: 'manage-limits', label: 'Limit Management', icon: 'bi-sliders' },
    ];

    const roleColors = {
        'REQUESTER': 'bg-blue-600',
        'APPROVER_1': 'bg-indigo-600',
        'APPROVER_2': 'bg-purple-600',
    };

    return (
        <>
            {/* Mobile Overlay Backdrop */}
            <div 
                className={`fixed inset-0 bg-black/50 z-40 lg:hidden backdrop-blur-sm transition-opacity duration-300 ${
                    isOpen ? 'opacity-100 pointer-events-auto' : 'opacity-0 pointer-events-none'
                }`}
                onClick={() => setIsOpen(false)}
            ></div>

            {/* Sidebar Container */}
            <div className={`
                fixed top-0 bottom-0 left-0 w-64 bg-slate-900 text-white shadow-2xl z-50 flex flex-col
                transition-transform duration-300 ease-in-out
                ${isOpen ? 'translate-x-0' : '-translate-x-full'}
                lg:translate-x-0 lg:fixed
            `}>
                <div className="p-6 flex items-center justify-between border-b border-slate-800">
                    <div className="flex items-center gap-3">
                        <div className="w-8 h-8 rounded bg-gradient-to-br from-emerald-400 to-blue-500 flex items-center justify-center text-xs font-bold text-slate-900">
                            PF
                        </div>
                        <h1 className="text-xl font-bold tracking-tight">ProcureFlow</h1>
                    </div>
                    {/* Mobile Close Button */}
                    <button 
                        onClick={() => setIsOpen(false)} 
                        className="lg:hidden text-slate-400 hover:text-white"
                    >
                        <i className="bi bi-x-lg text-lg"></i>
                    </button>
                </div>

                <div className="flex-1 py-6 px-3 space-y-6 overflow-y-auto">
                    {/* Main Menu */}
                    <div className="space-y-1">
                        <p className="px-3 text-xs font-semibold text-slate-500 uppercase tracking-wider mb-2">Menu</p>
                        {menuItems.map((item) => {
                            if (item.show === false) return null;
                            return (
                                <button
                                    key={item.id}
                                    onClick={() => {
                                        setActivePage(item.id);
                                        setIsOpen(false); // Close sidebar on mobile when clicked
                                    }}
                                    className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-all ${
                                        activePage === item.id 
                                        ? 'bg-slate-800 text-emerald-400 shadow-sm border-l-4 border-emerald-400' 
                                        : 'text-slate-400 hover:bg-slate-800/50 hover:text-slate-200'
                                    }`}
                                >
                                    <i className={`bi ${item.icon} text-lg`}></i>
                                    {item.label}
                                </button>
                            );
                        })}
                    </div>

                    {/* Administration Menu */}
                    <div className="space-y-1">
                         <p className="px-3 text-xs font-semibold text-slate-500 uppercase tracking-wider mb-2">Administration</p>
                         {adminItems.map((item) => (
                            <button
                                key={item.id}
                                onClick={() => {
                                    setActivePage(item.id);
                                    setIsOpen(false);
                                }}
                                className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-all ${
                                    activePage === item.id 
                                    ? 'bg-slate-800 text-emerald-400 shadow-sm border-l-4 border-emerald-400' 
                                    : 'text-slate-400 hover:bg-slate-800/50 hover:text-slate-200'
                                }`}
                            >
                                <i className={`bi ${item.icon} text-lg`}></i>
                                {item.label}
                            </button>
                         ))}
                    </div>
                </div>

                {/* User Role Switcher (Simulation only) */}
                <div className="p-4 border-t border-slate-800 bg-slate-950">
                    <p className="text-xs text-slate-500 mb-2 uppercase tracking-wider font-semibold">Simulate Role</p>
                    <div className="flex flex-col gap-2">
                        {(['REQUESTER', 'APPROVER_1', 'APPROVER_2'] as UserRole[]).map((r) => (
                            <button
                                key={r}
                                onClick={() => setRole(r)}
                                className={`text-xs py-2 px-3 rounded-md border transition-all flex justify-between items-center ${
                                    role === r 
                                    ? `${roleColors[r]} border-transparent text-white shadow-md` 
                                    : 'border-slate-800 text-slate-400 hover:border-slate-700 bg-slate-900'
                                }`}
                            >
                                <span>{r.replace('_', ' ')}</span>
                                {role === r && <i className="bi bi-check2"></i>}
                            </button>
                        ))}
                    </div>
                    <div className="mt-4 pt-4 border-t border-slate-800 text-center">
                         <p className="text-[10px] text-slate-600">v1.1.0 &bull; ProcureFlow System</p>
                    </div>
                </div>
            </div>
        </>
    );
};
