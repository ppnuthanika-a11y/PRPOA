import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { PurchaseRequest, PRStatus, DEFAULT_APPROVAL_LIMIT } from '../types';
import { analyzePRJustification } from '../services/geminiService';
import { generatePO_PDF, previewPR_PDF } from '../services/exportService';

interface PRListProps {
    filterStatus?: PRStatus[];
    isApprovalView?: boolean;
}

export const PRList: React.FC<PRListProps> = ({ filterStatus, isApprovalView = false }) => {
    const { requests, orders, role, approveRequest, rejectRequest, convertToPO, updateAIAnalysis, approvalLimits } = useApp();
    const [selectedPR, setSelectedPR] = useState<PurchaseRequest | null>(null);
    const [comment, setComment] = useState('');
    const [vendorName, setVendorName] = useState('');
    const [analyzing, setAnalyzing] = useState(false);

    // Determine dynamic limit or fallback
    const currentApprovalLimit = approvalLimits.length > 0 ? approvalLimits[0].amount : DEFAULT_APPROVAL_LIMIT;

    const filteredRequests = requests.filter(pr => {
        if (filterStatus && !filterStatus.includes(pr.status)) return false;
        
        if (isApprovalView) {
            if (role === 'APPROVER_1') return pr.status === PRStatus.PENDING_L1;
            if (role === 'APPROVER_2') return pr.status === PRStatus.PENDING_L2;
            return false;
        }
        return true;
    });

    const handleAnalyze = async (pr: PurchaseRequest) => {
        setAnalyzing(true);
        const result = await analyzePRJustification(pr);
        updateAIAnalysis(pr.id, result);
        setAnalyzing(false);
    };

    const getStatusBadge = (status: PRStatus) => {
        const styles = {
            [PRStatus.DRAFT]: 'bg-slate-100 text-slate-600 border-slate-200',
            [PRStatus.PENDING_L1]: 'bg-yellow-50 text-yellow-700 border-yellow-200',
            [PRStatus.PENDING_L2]: 'bg-orange-50 text-orange-700 border-orange-200',
            [PRStatus.APPROVED]: 'bg-green-50 text-green-700 border-green-200',
            [PRStatus.REJECTED]: 'bg-red-50 text-red-700 border-red-200',
            [PRStatus.CONVERTED_TO_PO]: 'bg-blue-50 text-blue-700 border-blue-200',
        };
        return (
            <span className={`px-2.5 py-1 rounded-full text-[10px] md:text-xs font-semibold whitespace-nowrap border ${styles[status]}`}>
                {status.replace('_', ' ')}
            </span>
        );
    };

    // Detail Modal
    const renderModal = () => {
        if (!selectedPR) return null;
        const canApprove = isApprovalView;
        const canConvert = selectedPR.status === PRStatus.APPROVED && role !== 'REQUESTER'; // Allow approvers/admins to convert
        const linkedPO = orders.find(o => o.prId === selectedPR.id);
        const showPreviewPDF = role === 'REQUESTER' && selectedPR.status === PRStatus.APPROVED;

        return (
            <div className="fixed inset-0 bg-black/60 flex items-center justify-center z-[60] p-2 md:p-4 backdrop-blur-sm transition-opacity">
                {/* Updated Width classes for full screen feel: w-[98%] max-w-7xl */}
                <div className="bg-white rounded-xl shadow-2xl w-full md:w-[95vw] max-w-7xl max-h-[95vh] overflow-hidden flex flex-col animate-fade-in-up">
                    {/* Modal Header */}
                    <div className="px-4 md:px-6 py-4 border-b border-slate-100 flex justify-between items-center bg-white shrink-0">
                        <div className="flex items-center gap-3 overflow-hidden">
                            <div className="bg-indigo-50 p-2 rounded-lg hidden md:block shrink-0">
                                <i className="bi bi-file-text text-indigo-600 text-xl"></i>
                            </div>
                            <div className="min-w-0">
                                <div className="flex flex-col md:flex-row md:items-center gap-1 md:gap-2">
                                    <h3 className="text-lg md:text-xl font-bold text-slate-900 truncate">{selectedPR.id}</h3>
                                    <div className="self-start">{getStatusBadge(selectedPR.status)}</div>
                                </div>
                                <p className="text-xs text-slate-500 mt-0.5 hidden md:block">Created on {selectedPR.date}</p>
                            </div>
                        </div>
                        <button onClick={() => setSelectedPR(null)} className="text-slate-400 hover:text-slate-600 p-2 hover:bg-slate-50 rounded-full transition shrink-0">
                            <i className="bi bi-x-lg text-lg"></i>
                        </button>
                    </div>

                    {/* Modal Body (Scrollable) */}
                    <div className="p-4 md:p-6 overflow-y-auto flex-1 space-y-6 md:space-y-8 bg-slate-50/30">
                        {/* Header Info Grid */}
                        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 md:gap-6">
                            <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-sm h-full">
                                <p className="text-xs font-bold text-slate-400 uppercase mb-2 tracking-wider">Requester Details</p>
                                <div className="flex items-center gap-4">
                                    <div className="w-12 h-12 rounded-full bg-slate-100 flex items-center justify-center text-slate-500 text-lg shrink-0">
                                        <i className="bi bi-person"></i>
                                    </div>
                                    <div className="min-w-0">
                                        <p className="text-slate-900 font-bold text-lg truncate">{selectedPR.requesterName}</p>
                                        <p className="text-indigo-600 text-sm font-medium truncate">{selectedPR.department} Department</p>
                                        <p className="text-xs text-slate-400 md:hidden mt-1">{selectedPR.date}</p>
                                    </div>
                                </div>
                                {showPreviewPDF && (
                                    <div className="mt-4 pt-4 border-t border-slate-100">
                                        <button 
                                            onClick={() => previewPR_PDF(selectedPR)}
                                            className="text-blue-600 hover:text-blue-800 text-sm font-bold flex items-center gap-2 hover:underline"
                                        >
                                            <i className="bi bi-file-earmark-pdf-fill text-lg"></i> View Approved Request PDF
                                        </button>
                                    </div>
                                )}
                            </div>
                             <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-sm h-full flex flex-col">
                                <div className="flex justify-between items-start mb-3">
                                    <p className="text-xs font-bold text-slate-400 uppercase tracking-wider">Justification</p>
                                    {selectedPR.aiAnalysis ? (
                                        <span className="text-[10px] bg-gradient-to-r from-indigo-500 to-purple-500 text-white px-2 py-0.5 rounded-full shadow-sm flex items-center gap-1 whitespace-nowrap">
                                            <i className="bi bi-stars"></i> AI Analyzed
                                        </span>
                                    ) : (
                                        <button 
                                            onClick={() => handleAnalyze(selectedPR)}
                                            disabled={analyzing}
                                            className="text-[10px] bg-slate-50 border border-slate-200 hover:bg-indigo-50 text-slate-600 hover:text-indigo-600 px-2 py-1 rounded shadow-sm flex items-center gap-1 transition"
                                        >
                                            {analyzing ? 'Thinking...' : <><i className="bi bi-stars text-indigo-500"></i> Analyze with AI</>}
                                        </button>
                                    )}
                                </div>
                                <p className="text-sm text-slate-700 italic leading-relaxed mb-3 flex-grow break-words">"{selectedPR.justification}"</p>
                                {selectedPR.aiAnalysis && (
                                     <div className="mt-auto pt-3 border-t border-slate-100 bg-indigo-50/50 -mx-2 px-3 py-2 rounded-md">
                                         <p className="text-xs font-semibold text-indigo-700 mb-1 flex items-center gap-1">
                                            <i className="bi bi-robot"></i> AI Assessment:
                                         </p>
                                         <p className="text-xs text-slate-600 leading-relaxed">{selectedPR.aiAnalysis}</p>
                                     </div>
                                )}
                             </div>
                        </div>

                        {/* Items Table / List */}
                        <div className="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden">
                            <div className="px-6 py-4 border-b border-slate-100">
                                <h4 className="text-sm font-bold text-slate-800 uppercase tracking-wider">Items Requested</h4>
                            </div>
                            
                            {/* Desktop Table for Modal - Hidden on Tablet Portrait (lg and below use stacked) */}
                            <div className="hidden lg:block overflow-x-auto">
                                <table className="w-full text-sm text-left">
                                    <thead className="bg-slate-50 text-slate-500 font-medium">
                                        <tr>
                                            <th className="px-6 py-3">Description</th>
                                            <th className="px-6 py-3 text-right">Qty</th>
                                            <th className="px-6 py-3 text-right">Unit Price</th>
                                            <th className="px-6 py-3 text-right">Total</th>
                                        </tr>
                                    </thead>
                                    <tbody className="divide-y divide-slate-100">
                                        {selectedPR.items.map((item, i) => (
                                            <tr key={i} className="bg-white hover:bg-slate-50/50">
                                                <td className="px-6 py-3 text-slate-800 font-medium">{item.description}</td>
                                                <td className="px-6 py-3 text-right text-slate-600">{item.quantity}</td>
                                                <td className="px-6 py-3 text-right text-slate-600">{item.unitPrice.toLocaleString()}</td>
                                                <td className="px-6 py-3 text-right font-bold text-slate-800">{item.total.toLocaleString()}</td>
                                            </tr>
                                        ))}
                                    </tbody>
                                    <tfoot className="bg-slate-50 border-t border-slate-200">
                                        <tr>
                                            <td colSpan={3} className="px-6 py-4 text-right font-bold text-slate-900 uppercase text-xs tracking-wide">Total Amount</td>
                                            <td className="px-6 py-4 text-right font-bold text-indigo-600 text-xl whitespace-nowrap">
                                                {selectedPR.totalAmount.toLocaleString()} THB
                                            </td>
                                        </tr>
                                    </tfoot>
                                </table>
                            </div>

                            {/* Mobile/Tablet Stacked List */}
                            <div className="lg:hidden divide-y divide-slate-100">
                                {selectedPR.items.map((item, i) => (
                                    <div key={i} className="p-4 bg-white">
                                        <div className="flex justify-between items-start mb-1">
                                            <span className="font-medium text-slate-800 text-sm">{item.description}</span>
                                            <span className="font-bold text-slate-900 text-sm">{item.total.toLocaleString()}</span>
                                        </div>
                                        <div className="flex justify-between text-xs text-slate-500">
                                            <span>Qty: {item.quantity}</span>
                                            <span>@ {item.unitPrice.toLocaleString()} / unit</span>
                                        </div>
                                    </div>
                                ))}
                                 <div className="p-4 bg-slate-50 flex justify-between items-center border-t border-slate-200">
                                    <span className="font-bold text-slate-900 uppercase text-xs tracking-wide">Total</span>
                                    <span className="font-bold text-indigo-600 text-lg">
                                        {selectedPR.totalAmount.toLocaleString()} THB
                                    </span>
                                </div>
                            </div>
                        </div>
                        
                        {/* Approval Warning */}
                        {selectedPR.totalAmount > currentApprovalLimit && selectedPR.status === PRStatus.PENDING_L1 && (
                            <div className="bg-amber-50 border border-amber-100 rounded-xl p-4 flex items-start gap-3 shadow-sm">
                                <i className="bi bi-exclamation-triangle-fill text-amber-500 text-xl mt-0.5 shrink-0"></i>
                                <div>
                                    <p className="font-bold text-amber-800 text-sm">High Value Request</p>
                                    <p className="text-xs text-amber-700 mt-1">
                                        Total exceeds {currentApprovalLimit.toLocaleString()} THB. 
                                        Secondary approval (L2) will be required after your endorsement.
                                    </p>
                                </div>
                            </div>
                        )}

                        {/* Actions Section */}
                        {canApprove && (
                            <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-sm space-y-4">
                                <h4 className="text-sm font-bold text-slate-800 uppercase">Approval Action</h4>
                                <textarea
                                    className="w-full p-3 text-sm border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500 outline-none bg-white transition"
                                    placeholder="Add a comment (optional)..."
                                    rows={2}
                                    value={comment}
                                    onChange={(e) => setComment(e.target.value)}
                                />
                                <div className="flex flex-col sm:flex-row gap-3">
                                    <button 
                                        onClick={() => { approveRequest(selectedPR.id, comment); setSelectedPR(null); setComment(''); }}
                                        className="flex-1 bg-emerald-600 text-white py-3 rounded-lg text-sm font-bold hover:bg-emerald-700 transition shadow-md hover:shadow-lg flex justify-center items-center gap-2"
                                    >
                                        <i className="bi bi-check-circle-fill"></i> Approve Request
                                    </button>
                                    <button 
                                        onClick={() => { rejectRequest(selectedPR.id, comment); setSelectedPR(null); setComment(''); }}
                                        className="flex-1 bg-white text-red-600 border border-red-200 py-3 rounded-lg text-sm font-bold hover:bg-red-50 transition shadow-sm hover:shadow flex justify-center items-center gap-2"
                                    >
                                        <i className="bi bi-x-circle-fill"></i> Reject Request
                                    </button>
                                </div>
                            </div>
                        )}

                        {canConvert && !linkedPO && (
                            <div className="bg-indigo-50 p-6 rounded-xl border border-indigo-100 space-y-4 shadow-sm">
                                <div className="flex items-center gap-2 text-indigo-800">
                                    <i className="bi bi-bag-check-fill text-xl"></i>
                                    <h4 className="text-sm font-bold uppercase">Generate Purchase Order</h4>
                                </div>
                                <div className="flex flex-col sm:flex-row gap-3">
                                    <input 
                                        type="text"
                                        className="flex-1 px-4 py-3 border border-indigo-200 rounded-lg text-sm focus:ring-2 focus:ring-indigo-500 outline-none shadow-sm"
                                        placeholder="Enter Vendor / Supplier Name"
                                        value={vendorName}
                                        onChange={e => setVendorName(e.target.value)}
                                    />
                                    <button 
                                        disabled={!vendorName}
                                        onClick={() => { convertToPO(selectedPR.id, vendorName); setSelectedPR(null); setVendorName(''); }}
                                        className="bg-indigo-600 disabled:bg-indigo-300 text-white px-8 py-3 rounded-lg text-sm font-bold hover:bg-indigo-700 transition whitespace-nowrap shadow-md disabled:shadow-none"
                                    >
                                        Convert to PO
                                    </button>
                                </div>
                            </div>
                        )}

                        {linkedPO && (
                            <div className="bg-blue-50 border border-blue-100 rounded-xl p-6 flex flex-col sm:flex-row justify-between items-center gap-4 shadow-sm">
                                <div className="flex items-center gap-4">
                                    <div className="bg-white p-3 rounded-full shadow-sm shrink-0">
                                        <i className="bi bi-check2-all text-blue-600 text-xl"></i>
                                    </div>
                                    <div className="min-w-0">
                                        <p className="text-sm font-bold text-blue-900 truncate">Converted to Order: <span className="font-mono">{linkedPO.poNumber}</span></p>
                                        <p className="text-xs text-blue-700 mt-0.5 truncate">Vendor: {linkedPO.vendorName}</p>
                                    </div>
                                </div>
                                <button 
                                    onClick={() => generatePO_PDF(linkedPO)}
                                    className="w-full sm:w-auto text-blue-700 hover:text-blue-900 bg-white border border-blue-200 px-6 py-2.5 rounded-lg text-sm font-medium flex items-center justify-center gap-2 shadow-sm hover:shadow-md transition"
                                >
                                    <i className="bi bi-file-earmark-pdf-fill"></i> Download PO
                                </button>
                            </div>
                        )}
                    </div>
                </div>
            </div>
        );
    };

    return (
        <div className="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden flex-1 flex flex-col">
            {/* Desktop Table View - Changed from md:block to xl:block to handle Tablet Portrait/Landscape scrolling */}
            <div className="hidden xl:block overflow-x-auto flex-1">
                <table className="w-full text-sm text-left min-w-[900px]">
                    <thead className="bg-slate-50 text-slate-500 font-semibold border-b border-slate-200">
                        <tr>
                            <th className="px-6 py-4">Request ID</th>
                            <th className="px-6 py-4">Date</th>
                            <th className="px-6 py-4">Requester</th>
                            <th className="px-6 py-4">Department</th>
                            <th className="px-6 py-4 text-right">Amount</th>
                            <th className="px-6 py-4 text-center">Status</th>
                            <th className="px-6 py-4 text-center">Action</th>
                        </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                        {filteredRequests.length === 0 ? (
                            <tr>
                                <td colSpan={7} className="px-6 py-12 text-center text-slate-400">
                                    <div className="flex flex-col items-center gap-3">
                                        <div className="w-16 h-16 bg-slate-50 rounded-full flex items-center justify-center">
                                            <i className="bi bi-inbox text-3xl text-slate-300"></i>
                                        </div>
                                        <p className="font-medium">No requests found matching your criteria.</p>
                                    </div>
                                </td>
                            </tr>
                        ) : (
                            filteredRequests.map((pr) => (
                                <tr key={pr.id} className="hover:bg-slate-50 transition group cursor-pointer" onClick={() => setSelectedPR(pr)}>
                                    <td className="px-6 py-4 font-medium text-indigo-600 group-hover:text-indigo-700 font-mono">{pr.id}</td>
                                    <td className="px-6 py-4 text-slate-600">{pr.date}</td>
                                    <td className="px-6 py-4 text-slate-800 font-medium">{pr.requesterName}</td>
                                    <td className="px-6 py-4 text-slate-600">
                                        <span className="px-2.5 py-1 bg-slate-100 rounded text-xs text-slate-600 font-medium">{pr.department}</span>
                                    </td>
                                    <td className="px-6 py-4 text-right font-bold text-slate-800">
                                        {new Intl.NumberFormat('th-TH', { style: 'currency', currency: 'THB' }).format(pr.totalAmount)}
                                    </td>
                                    <td className="px-6 py-4 text-center">
                                        {getStatusBadge(pr.status)}
                                    </td>
                                    <td className="px-6 py-4 text-center flex items-center justify-center gap-2">
                                        <button 
                                            onClick={(e) => { e.stopPropagation(); setSelectedPR(pr); }}
                                            className="text-slate-400 hover:text-indigo-600 transition p-2 rounded-full hover:bg-indigo-50"
                                            title="View Details"
                                        >
                                            <i className="bi bi-eye-fill text-lg"></i>
                                        </button>
                                        {pr.status === PRStatus.CONVERTED_TO_PO && (
                                            <button
                                                onClick={(e) => {
                                                    e.stopPropagation();
                                                    const po = orders.find(o => o.prId === pr.id);
                                                    if (po) generatePO_PDF(po);
                                                }}
                                                className="text-red-500 hover:text-red-700 transition p-2 rounded-full hover:bg-red-50"
                                                title="Download PO PDF"
                                            >
                                                <i className="bi bi-file-earmark-arrow-down-fill text-lg"></i>
                                            </button>
                                        )}
                                        {role === 'REQUESTER' && pr.status === PRStatus.APPROVED && (
                                            <button
                                                onClick={(e) => {
                                                    e.stopPropagation();
                                                    previewPR_PDF(pr);
                                                }}
                                                className="text-blue-500 hover:text-blue-700 transition p-2 rounded-full hover:bg-blue-50"
                                                title="View Approved PDF"
                                            >
                                                <i className="bi bi-file-earmark-pdf-fill text-lg"></i>
                                            </button>
                                        )}
                                    </td>
                                </tr>
                            ))
                        )}
                    </tbody>
                </table>
            </div>

            {/* Card View - Changed from md:hidden to xl:hidden so Tablets use this view */}
            <div className="xl:hidden flex-1 bg-slate-50 p-4 space-y-4 overflow-y-auto">
                {filteredRequests.length === 0 ? (
                    <div className="flex flex-col items-center justify-center py-10 text-slate-400">
                        <i className="bi bi-inbox text-4xl mb-3"></i>
                        <p>No requests found.</p>
                    </div>
                ) : (
                    filteredRequests.map((pr) => (
                        <div key={pr.id} onClick={() => setSelectedPR(pr)} className="bg-white border border-slate-200 rounded-lg p-4 shadow-sm active:scale-[0.98] transition duration-150 cursor-pointer">
                            <div className="flex justify-between items-center mb-3">
                                <span className="font-mono text-xs font-bold text-indigo-600 bg-indigo-50 px-2 py-1 rounded">{pr.id}</span>
                                {getStatusBadge(pr.status)}
                            </div>
                            <div className="mb-3">
                                <h4 className="font-bold text-slate-800 text-sm">{pr.requesterName}</h4>
                                <p className="text-xs text-slate-500 flex items-center gap-2 mt-1">
                                    <span className="px-1.5 py-0.5 bg-slate-100 rounded">{pr.department}</span>
                                    <span>• {pr.date}</span>
                                </p>
                            </div>
                            <div className="flex justify-between items-center pt-3 border-t border-slate-100">
                                <span className="text-xs text-slate-400">Total Amount</span>
                                <div className="flex items-center gap-2">
                                    <span className="font-bold text-slate-800">
                                        {new Intl.NumberFormat('th-TH', { style: 'currency', currency: 'THB' }).format(pr.totalAmount)}
                                    </span>
                                    {pr.status === PRStatus.CONVERTED_TO_PO && (
                                        <button
                                            onClick={(e) => {
                                                e.stopPropagation();
                                                const po = orders.find(o => o.prId === pr.id);
                                                if (po) generatePO_PDF(po);
                                            }}
                                            className="w-8 h-8 flex items-center justify-center rounded-full bg-red-50 text-red-500 hover:bg-red-100 transition"
                                        >
                                            <i className="bi bi-file-earmark-arrow-down-fill"></i>
                                        </button>
                                    )}
                                    {role === 'REQUESTER' && pr.status === PRStatus.APPROVED && (
                                        <button
                                            onClick={(e) => {
                                                e.stopPropagation();
                                                previewPR_PDF(pr);
                                            }}
                                            className="w-8 h-8 flex items-center justify-center rounded-full bg-blue-50 text-blue-500 hover:bg-blue-100 transition"
                                        >
                                            <i className="bi bi-file-earmark-pdf-fill"></i>
                                        </button>
                                    )}
                                    {!pr.status.includes('CONVERTED') && !(role === 'REQUESTER' && pr.status === PRStatus.APPROVED) && <i className="bi bi-chevron-right text-slate-300 text-xs"></i>}
                                </div>
                            </div>
                        </div>
                    ))
                )}
            </div>

            {renderModal()}
        </div>
    );
};