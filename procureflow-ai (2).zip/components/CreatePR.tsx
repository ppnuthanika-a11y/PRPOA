import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { LineItem } from '../types';

export const CreatePR: React.FC<{ onCancel: () => void }> = ({ onCancel }) => {
    const { createRequest } = useApp();
    const [department, setDepartment] = useState('');
    const [justification, setJustification] = useState('');
    const [requesterName, setRequesterName] = useState('');
    const [items, setItems] = useState<LineItem[]>([
        { id: '1', description: '', quantity: 1, unitPrice: 0, total: 0 }
    ]);

    const updateItem = (id: string, field: keyof LineItem, value: any) => {
        setItems(items.map(item => {
            if (item.id === id) {
                const updated = { ...item, [field]: value };
                if (field === 'quantity' || field === 'unitPrice') {
                    updated.total = Number(updated.quantity) * Number(updated.unitPrice);
                }
                return updated;
            }
            return item;
        }));
    };

    const addItem = () => {
        const id = Math.random().toString(36).substr(2, 9);
        setItems([...items, { id, description: '', quantity: 1, unitPrice: 0, total: 0 }]);
    };

    const removeItem = (id: string) => {
        if (items.length > 1) {
            setItems(items.filter(i => i.id !== id));
        }
    };

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        const totalAmount = items.reduce((sum, item) => sum + item.total, 0);
        createRequest({
            requesterName,
            department,
            date: new Date().toISOString().split('T')[0],
            justification,
            items,
            totalAmount
        });
        onCancel();
    };

    return (
        <div className="w-full bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden flex flex-col h-full">
            <div className="px-4 md:px-8 py-5 border-b border-slate-100 bg-slate-50 flex justify-between items-center">
                <div>
                    <h2 className="text-lg md:text-xl font-bold text-slate-800">New Purchase Request</h2>
                    <p className="text-xs md:text-sm text-slate-500 mt-1 hidden md:block">Fill in the details below to submit a new procurement request.</p>
                </div>
                <button onClick={onCancel} className="text-slate-400 hover:text-slate-600 p-2 hover:bg-slate-100 rounded-full transition">
                    <i className="bi bi-x-lg text-xl"></i>
                </button>
            </div>
            
            <form onSubmit={handleSubmit} className="p-4 md:p-8 space-y-8 flex-1 overflow-y-auto">
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 md:gap-8">
                    <div className="space-y-6 h-full">
                         <div className="bg-slate-50 p-4 md:p-6 rounded-xl border border-slate-100 h-full">
                            <h3 className="text-sm font-bold text-slate-700 uppercase tracking-wider mb-6 border-b border-slate-200 pb-2">Requester Info</h3>
                            <div className="grid grid-cols-1 gap-6">
                                <div>
                                    <label className="block text-sm font-medium text-slate-700 mb-2">Requester Name</label>
                                    <input 
                                        required
                                        type="text" 
                                        className="w-full px-4 py-3 rounded-lg border border-slate-300 focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 outline-none transition bg-white"
                                        value={requesterName}
                                        onChange={e => setRequesterName(e.target.value)}
                                        placeholder="e.g. John Doe"
                                    />
                                </div>
                                <div>
                                    <label className="block text-sm font-medium text-slate-700 mb-2">Department</label>
                                    <select 
                                        required
                                        className="w-full px-4 py-3 rounded-lg border border-slate-300 focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 outline-none bg-white"
                                        value={department}
                                        onChange={e => setDepartment(e.target.value)}
                                    >
                                        <option value="">Select Department...</option>
                                        <option value="IT">IT Department</option>
                                        <option value="HR">Human Resources</option>
                                        <option value="Marketing">Marketing</option>
                                        <option value="Operations">Operations</option>
                                        <option value="Finance">Finance</option>
                                    </select>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div className="space-y-6 h-full">
                        <div className="bg-slate-50 p-4 md:p-6 rounded-xl border border-slate-100 h-full flex flex-col">
                            <h3 className="text-sm font-bold text-slate-700 uppercase tracking-wider mb-6 border-b border-slate-200 pb-2">Justification</h3>
                            <div className="flex-1">
                                <label className="block text-sm font-medium text-slate-700 mb-2">Reason for Purchase</label>
                                <textarea 
                                    required
                                    rows={5}
                                    className="w-full h-full min-h-[150px] px-4 py-3 rounded-lg border border-slate-300 focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 outline-none transition bg-white resize-none"
                                    placeholder="Please provide a detailed explanation for why these items are needed..."
                                    value={justification}
                                    onChange={e => setJustification(e.target.value)}
                                />
                            </div>
                        </div>
                    </div>
                </div>

                <div className="border-t border-slate-100 pt-8">
                    <div className="flex justify-between items-center mb-6">
                        <h3 className="text-lg font-bold text-slate-800">Line Items</h3>
                        <button 
                            type="button"
                            onClick={addItem}
                            className="text-sm text-white bg-indigo-600 hover:bg-indigo-700 px-5 py-2.5 rounded-lg font-medium flex items-center gap-2 transition shadow-sm"
                        >
                            <i className="bi bi-plus-lg"></i> Add Item
                        </button>
                    </div>
                    
                    <div className="space-y-3">
                        {items.map((item, idx) => (
                            <div key={item.id} className="flex flex-col md:flex-row gap-3 md:gap-4 items-start bg-slate-50 p-3 md:p-4 rounded-xl border border-slate-200 shadow-sm hover:shadow-md transition-shadow">
                                <div className="flex-1 w-full">
                                    <label className="block text-xs font-semibold text-slate-500 mb-1 uppercase">Description</label>
                                    <input 
                                        type="text" 
                                        placeholder="Item Description"
                                        required
                                        className="w-full px-3 py-2.5 rounded-lg border border-slate-300 text-sm focus:border-indigo-500 outline-none"
                                        value={item.description}
                                        onChange={e => updateItem(item.id, 'description', e.target.value)}
                                    />
                                </div>
                                <div className="flex gap-2 md:gap-4 w-full md:w-auto">
                                    <div className="w-1/3 md:w-32">
                                        <label className="block text-xs font-semibold text-slate-500 mb-1 uppercase">Qty</label>
                                        <input 
                                            type="number" 
                                            min="1"
                                            required
                                            className="w-full px-3 py-2.5 rounded-lg border border-slate-300 text-sm focus:border-indigo-500 outline-none text-right"
                                            value={item.quantity}
                                            onChange={e => updateItem(item.id, 'quantity', Number(e.target.value))}
                                        />
                                    </div>
                                    <div className="w-2/3 md:w-40">
                                        <label className="block text-xs font-semibold text-slate-500 mb-1 uppercase">Unit Price (THB)</label>
                                        <input 
                                            type="number" 
                                            min="0"
                                            step="0.01"
                                            required
                                            placeholder="0.00"
                                            className="w-full px-3 py-2.5 rounded-lg border border-slate-300 text-sm focus:border-indigo-500 outline-none text-right"
                                            value={item.unitPrice || ''}
                                            onChange={e => updateItem(item.id, 'unitPrice', Number(e.target.value))}
                                        />
                                    </div>
                                </div>
                                <div className="w-full md:w-40 flex justify-between md:block md:text-right bg-white md:bg-transparent p-3 md:p-0 rounded border md:border-0 border-slate-200">
                                    <span className="md:hidden text-sm font-medium text-slate-700 self-center">Subtotal:</span>
                                    <div>
                                        <label className="hidden md:block text-xs font-semibold text-slate-500 mb-1 uppercase">Total</label>
                                        <span className="text-sm font-bold text-slate-900 block py-2 md:py-2.5">
                                            {new Intl.NumberFormat('th-TH', { style: 'currency', currency: 'THB' }).format(item.total)}
                                        </span>
                                    </div>
                                </div>
                                <div className="self-end md:self-center pb-1 md:pb-0">
                                    <button 
                                        type="button" 
                                        onClick={() => removeItem(item.id)}
                                        className="w-10 h-10 flex items-center justify-center text-slate-400 hover:text-red-500 hover:bg-red-50 rounded-full transition"
                                        disabled={items.length === 1}
                                        title="Remove item"
                                    >
                                        <i className="bi bi-trash"></i>
                                    </button>
                                </div>
                            </div>
                        ))}
                    </div>
                </div>

                <div className="flex flex-col-reverse md:flex-row justify-end items-center gap-4 pt-6 border-t border-slate-100 mt-8">
                    <button 
                        type="button" 
                        onClick={onCancel}
                        className="w-full md:w-auto px-6 py-3.5 text-sm font-medium text-slate-600 bg-white border border-slate-200 rounded-lg hover:bg-slate-50 transition"
                    >
                        Cancel Request
                    </button>
                    <div className="flex flex-col md:flex-row items-center gap-4 w-full md:w-auto bg-slate-50 md:bg-transparent p-4 md:p-0 rounded-xl w-full">
                        <div className="text-right w-full md:w-auto">
                            <span className="text-sm text-slate-500 mr-2">Grand Total:</span>
                            <span className="text-2xl font-bold text-slate-800">
                                {new Intl.NumberFormat('th-TH', { style: 'currency', currency: 'THB' }).format(items.reduce((s, i) => s + i.total, 0))}
                            </span>
                        </div>
                        <button 
                            type="submit" 
                            className="w-full md:w-auto px-10 py-3.5 text-sm font-bold text-white bg-gradient-to-r from-indigo-600 to-blue-600 rounded-lg hover:from-indigo-700 hover:to-blue-700 shadow-md hover:shadow-lg transition transform hover:-translate-y-0.5"
                        >
                            Submit Request
                        </button>
                    </div>
                </div>
            </form>
        </div>
    );
};