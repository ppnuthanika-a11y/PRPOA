
import React, { createContext, useContext, useState, useEffect } from 'react';
import { PurchaseRequest, PurchaseOrder, UserRole, PRStatus, LineItem, User, ApprovalLimit, DEFAULT_APPROVAL_LIMIT } from '../types';

interface AppContextType {
  role: UserRole;
  setRole: (role: UserRole) => void;
  
  // Data
  requests: PurchaseRequest[];
  orders: PurchaseOrder[];
  users: User[];
  approvalLimits: ApprovalLimit[];

  // Actions
  createRequest: (data: Omit<PurchaseRequest, 'id' | 'status' | 'approvalHistory' | 'aiAnalysis'>) => void;
  approveRequest: (id: string, comment: string) => void;
  rejectRequest: (id: string, comment: string) => void;
  convertToPO: (prId: string, vendorName: string) => void;
  updateAIAnalysis: (prId: string, analysis: string) => void;

  // Management Actions
  addUser: (user: User) => void;
  updateUser: (user: User) => void;
  deleteUser: (id: string) => void;
  
  addLimit: (limit: ApprovalLimit) => void;
  updateLimit: (limit: ApprovalLimit) => void;
  deleteLimit: (id: string) => void;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

// Mock Data
const MOCK_USERS: User[] = [
    { id: 'u1', name: 'Somsak Jai-dee', email: 'somsak@procureflow.com', role: 'REQUESTER', department: 'IT', approver1Id: 'u2', approver2Id: 'u3' },
    { id: 'u2', name: 'Piyachart (Mgr)', email: 'piyachart@procureflow.com', role: 'APPROVER_1', department: 'IT' },
    { id: 'u3', name: 'Sureeporn (Dir)', email: 'sureeporn@procureflow.com', role: 'APPROVER_2', department: 'Executive' },
    { id: 'u4', name: 'Manee Meeta', email: 'manee@procureflow.com', role: 'REQUESTER', department: 'HR', approver1Id: 'u2', approver2Id: 'u3' },
];

const MOCK_LIMITS: ApprovalLimit[] = [
    { id: 'l1', name: 'Level 1 Threshold', amount: 50000, description: 'Maximum amount a Level 1 Approver can authorize without Level 2.' }
];

const MOCK_REQUESTS: PurchaseRequest[] = [
    {
        id: 'PR-2023-001',
        requesterName: 'Somsak Jai-dee',
        department: 'IT',
        date: '2023-10-25',
        justification: 'Need new laptops for new developers.',
        items: [
            { id: '1', description: 'MacBook Pro M2', quantity: 2, unitPrice: 45000, total: 90000 }
        ],
        totalAmount: 90000,
        status: PRStatus.PENDING_L1,
        approvalHistory: [],
        aiAnalysis: "High value item. Consistent with IT department needs."
    },
    {
        id: 'PR-2023-002',
        requesterName: 'Manee Meeta',
        department: 'HR',
        date: '2023-10-26',
        justification: 'Office supplies for Q4.',
        items: [
            { id: '1', description: 'A4 Paper Double A', quantity: 50, unitPrice: 120, total: 6000 },
            { id: '2', description: 'Blue Pens', quantity: 100, unitPrice: 10, total: 1000 }
        ],
        totalAmount: 7000,
        status: PRStatus.PENDING_L1,
        approvalHistory: []
    },
     {
        id: 'PR-2023-003',
        requesterName: 'Somsak Jai-dee',
        department: 'IT',
        date: '2023-10-27',
        justification: 'Emergency server maintenance kit.',
        items: [
            { id: '1', description: 'Server PSU', quantity: 1, unitPrice: 15000, total: 15000 }
        ],
        totalAmount: 15000,
        status: PRStatus.APPROVED,
        approvalHistory: [
             { role: 'REQUESTER', action: 'SUBMIT', date: '2023-10-27T09:00:00Z' },
             { role: 'APPROVER_1', action: 'APPROVE', date: '2023-10-27T10:30:00Z', comment: 'Approved for emergency.' }
        ]
    }
];

const MOCK_ORDERS: PurchaseOrder[] = [
     {
        poNumber: 'PO-2023-001',
        prId: 'PR-2023-003',
        vendorName: 'Cisco Systems Thailand',
        generatedDate: '2023-10-28T14:00:00Z',
        prSnapshot: MOCK_REQUESTS[2] // Using the approved one
    }
];

// Ensure the mock approved request is marked as converted in the mock requests list
MOCK_REQUESTS[2].status = PRStatus.CONVERTED_TO_PO;


export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [role, setRole] = useState<UserRole>('REQUESTER');
  const [requests, setRequests] = useState<PurchaseRequest[]>(MOCK_REQUESTS);
  const [orders, setOrders] = useState<PurchaseOrder[]>(MOCK_ORDERS);
  const [users, setUsers] = useState<User[]>(MOCK_USERS);
  const [approvalLimits, setApprovalLimits] = useState<ApprovalLimit[]>(MOCK_LIMITS);

  const createRequest = (data: Omit<PurchaseRequest, 'id' | 'status' | 'approvalHistory' | 'aiAnalysis'>) => {
    const newPR: PurchaseRequest = {
      ...data,
      id: `PR-${new Date().getFullYear()}-${String(requests.length + 1).padStart(3, '0')}`,
      status: PRStatus.PENDING_L1,
      approvalHistory: [{ role: 'REQUESTER', action: 'SUBMIT', date: new Date().toISOString() }]
    };
    setRequests([newPR, ...requests]);
  };

  const approveRequest = (id: string, comment: string) => {
    setRequests(prev => prev.map(pr => {
      if (pr.id !== id) return pr;

      let newStatus = pr.status;
      
      // Dynamic Limit Check
      const limitConfig = approvalLimits.length > 0 ? approvalLimits[0].amount : DEFAULT_APPROVAL_LIMIT;

      if (role === 'APPROVER_1') {
        // Logic: If amount <= Limit, go to Approved. If > Limit, go to L2.
        if (pr.totalAmount <= limitConfig) {
            newStatus = PRStatus.APPROVED;
        } else {
            newStatus = PRStatus.PENDING_L2;
        }
      } else if (role === 'APPROVER_2') {
        newStatus = PRStatus.APPROVED;
      }

      return {
        ...pr,
        status: newStatus,
        approvalHistory: [...pr.approvalHistory, { role, action: 'APPROVE', date: new Date().toISOString(), comment }]
      };
    }));
  };

  const rejectRequest = (id: string, comment: string) => {
    setRequests(prev => prev.map(pr => {
      if (pr.id !== id) return pr;
      return {
        ...pr,
        status: PRStatus.REJECTED,
        approvalHistory: [...pr.approvalHistory, { role, action: 'REJECT', date: new Date().toISOString(), comment }]
      };
    }));
  };

  const convertToPO = (prId: string, vendorName: string) => {
    setRequests(prev => prev.map(pr => {
        if (pr.id !== prId) return pr;
        
        const newPO: PurchaseOrder = {
            poNumber: `PO-${new Date().getFullYear()}-${String(orders.length + 1).padStart(3, '0')}`,
            prId: pr.id,
            vendorName,
            generatedDate: new Date().toISOString(),
            prSnapshot: pr
        };
        
        setOrders([newPO, ...orders]);
        return { ...pr, status: PRStatus.CONVERTED_TO_PO };
    }));
  };

  const updateAIAnalysis = (prId: string, analysis: string) => {
      setRequests(prev => prev.map(pr => pr.id === prId ? { ...pr, aiAnalysis: analysis } : pr));
  };

  // User Management
  const addUser = (user: User) => setUsers([...users, user]);
  const updateUser = (user: User) => setUsers(users.map(u => u.id === user.id ? user : u));
  const deleteUser = (id: string) => setUsers(users.filter(u => u.id !== id));

  // Limit Management
  const addLimit = (limit: ApprovalLimit) => setApprovalLimits([...approvalLimits, limit]);
  const updateLimit = (limit: ApprovalLimit) => setApprovalLimits(approvalLimits.map(l => l.id === limit.id ? limit : l));
  const deleteLimit = (id: string) => setApprovalLimits(approvalLimits.filter(l => l.id !== id));

  return (
    <AppContext.Provider value={{ 
        role, setRole, 
        requests, orders, users, approvalLimits,
        createRequest, approveRequest, rejectRequest, convertToPO, updateAIAnalysis,
        addUser, updateUser, deleteUser,
        addLimit, updateLimit, deleteLimit
    }}>
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) throw new Error("useApp must be used within AppProvider");
  return context;
};
